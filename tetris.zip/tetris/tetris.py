#!/usr/bin/env python3
"""
Modern Tetris - Clean, animated, with high score system.
Perfect for GitHub portfolios.

Controls:
  ← →     Move
  ↑       Rotate
  ↓       Soft drop
  Space   Hard drop
  P       Pause
  R       Restart (after game over)
  Esc     Quit
"""

import pygame
import random
import os
from pathlib import Path

# ──────────────────────────────────────────────
# Configuration
# ──────────────────────────────────────────────
CELL = 30
COLS, ROWS = 10, 20
WIDTH = CELL * (COLS + 8)          # extra space for sidebar
HEIGHT = CELL * ROWS
FPS = 60

# Colors (modern dark theme)
BG = (18, 18, 27)
GRID = (40, 40, 55)
SIDEBAR_BG = (24, 24, 36)
WHITE = (240, 240, 255)
GRAY = (140, 140, 160)
YELLOW = (250, 220, 50)

# Tetromino colors (vibrant)
COLORS = {
    "I": (0, 240, 240),
    "O": (240, 240, 0),
    "T": (160, 0, 240),
    "S": (0, 240, 0),
    "Z": (240, 0, 0),
    "J": (0, 0, 240),
    "L": (240, 160, 0),
}

SHAPES = {
    "I": [[1, 1, 1, 1]],
    "O": [[1, 1],
          [1, 1]],
    "T": [[0, 1, 0],
          [1, 1, 1]],
    "S": [[0, 1, 1],
          [1, 1, 0]],
    "Z": [[1, 1, 0],
          [0, 1, 1]],
    "J": [[1, 0, 0],
          [1, 1, 1]],
    "L": [[0, 0, 1],
          [1, 1, 1]],
}

HIGHSCORE_FILE = Path(__file__).parent / "highscore.txt"


# ──────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────
def load_highscore() -> int:
    try:
        return int(HIGHSCORE_FILE.read_text().strip())
    except (FileNotFoundError, ValueError):
        return 0


def save_highscore(score: int):
    HIGHSCORE_FILE.write_text(str(score))


def rotate(shape):
    """Rotate matrix 90° clockwise."""
    return [list(row) for row in zip(*shape[::-1])]


# ──────────────────────────────────────────────
# Tetromino
# ──────────────────────────────────────────────
class Piece:
    def __init__(self, kind=None):
        self.kind = kind or random.choice(list(SHAPES.keys()))
        self.shape = [row[:] for row in SHAPES[self.kind]]
        self.color = COLORS[self.kind]
        self.x = COLS // 2 - len(self.shape[0]) // 2
        self.y = 0

    def rotate(self):
        self.shape = rotate(self.shape)


# ──────────────────────────────────────────────
# Game
# ──────────────────────────────────────────────
class Tetris:
    def __init__(self):
        pygame.init()
        pygame.display.set_caption("Tetris")
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
        self.clock = pygame.time.Clock()
        self.font = pygame.font.SysFont("Consolas", 22, bold=True)
        self.big_font = pygame.font.SysFont("Consolas", 42, bold=True)
        self.small_font = pygame.font.SysFont("Consolas", 16)

        self.highscore = load_highscore()
        self.reset()

    def reset(self):
        self.board = [[None for _ in range(COLS)] for _ in range(ROWS)]
        self.current = Piece()
        self.next_piece = Piece()
        self.score = 0
        self.level = 1
        self.lines_cleared = 0
        self.fall_time = 0
        self.fall_speed = 500          # ms
        self.game_over = False
        self.paused = False
        self.clear_anim = None         # for line-clear flash
        self.anim_timer = 0

    def valid(self, piece, dx=0, dy=0, shape=None):
        shape = shape or piece.shape
        for y, row in enumerate(shape):
            for x, cell in enumerate(row):
                if cell:
                    nx, ny = piece.x + x + dx, piece.y + y + dy
                    if nx < 0 or nx >= COLS or ny >= ROWS:
                        return False
                    if ny >= 0 and self.board[ny][nx]:
                        return False
        return True

    def lock(self):
        for y, row in enumerate(self.current.shape):
            for x, cell in enumerate(row):
                if cell:
                    by = self.current.y + y
                    bx = self.current.x + x
                    if by < 0:
                        self.game_over = True
                        return
                    self.board[by][bx] = self.current.color

        # Check lines
        full = [i for i, row in enumerate(self.board) if all(row)]
        if full:
            self.clear_anim = full
            self.anim_timer = 12       # frames of flash
        else:
            self.spawn()

    def finish_clear(self):
        # Remove the lines and add empty ones at top
        for i in sorted(self.clear_anim, reverse=True):
            del self.board[i]
            self.board.insert(0, [None] * COLS)

        n = len(self.clear_anim)
        points = {1: 100, 2: 300, 3: 500, 4: 800}
        self.score += points.get(n, 0) * self.level
        self.lines_cleared += n
        self.level = self.lines_cleared // 10 + 1
        self.fall_speed = max(80, 500 - (self.level - 1) * 40)

        if self.score > self.highscore:
            self.highscore = self.score
            save_highscore(self.highscore)

        self.clear_anim = None
        self.spawn()

    def spawn(self):
        self.current = self.next_piece
        self.next_piece = Piece()
        if not self.valid(self.current):
            self.game_over = True

    def hard_drop(self):
        while self.valid(self.current, dy=1):
            self.current.y += 1
            self.score += 2
        self.lock()

    def update(self, dt):
        if self.game_over or self.paused:
            return

        # Line clear animation
        if self.clear_anim is not None:
            self.anim_timer -= 1
            if self.anim_timer <= 0:
                self.finish_clear()
            return

        self.fall_time += dt
        if self.fall_time >= self.fall_speed:
            self.fall_time = 0
            if self.valid(self.current, dy=1):
                self.current.y += 1
            else:
                self.lock()

    def draw_cell(self, x, y, color, ghost=False):
        rect = pygame.Rect(x * CELL, y * CELL, CELL, CELL)
        if ghost:
            s = pygame.Surface((CELL, CELL), pygame.SRCALPHA)
            s.fill((*color, 60))
            self.screen.blit(s, rect)
            pygame.draw.rect(self.screen, (*color, 120), rect, 2)
        else:
            pygame.draw.rect(self.screen, color, rect)
            # subtle highlight
            pygame.draw.rect(self.screen, tuple(min(255, c + 40) for c in color), rect, 2)
            pygame.draw.rect(self.screen, (0, 0, 0), rect, 1)

    def draw(self):
        self.screen.fill(BG)

        # Grid
        for y in range(ROWS):
            for x in range(COLS):
                pygame.draw.rect(self.screen, GRID, (x * CELL, y * CELL, CELL, CELL), 1)

        # Locked pieces + clear animation flash
        for y, row in enumerate(self.board):
            for x, color in enumerate(row):
                if color:
                    if self.clear_anim and y in self.clear_anim and self.anim_timer % 4 < 2:
                        self.draw_cell(x, y, WHITE)
                    else:
                        self.draw_cell(x, y, color)

        # Ghost piece
        if not self.game_over and self.clear_anim is None:
            ghost_y = 0
            while self.valid(self.current, dy=ghost_y + 1):
                ghost_y += 1
            for y, row in enumerate(self.current.shape):
                for x, cell in enumerate(row):
                    if cell:
                        self.draw_cell(self.current.x + x, self.current.y + y + ghost_y,
                                       self.current.color, ghost=True)

        # Current piece
        if not self.game_over and self.clear_anim is None:
            for y, row in enumerate(self.current.shape):
                for x, cell in enumerate(row):
                    if cell:
                        self.draw_cell(self.current.x + x, self.current.y + y, self.current.color)

        # Sidebar
        sidebar_x = COLS * CELL + 10
        pygame.draw.rect(self.screen, SIDEBAR_BG, (COLS * CELL, 0, WIDTH - COLS * CELL, HEIGHT))

        # Next piece
        self.screen.blit(self.font.render("NEXT", True, GRAY), (sidebar_x, 20))
        next_shape = self.next_piece.shape
        ox = sidebar_x + 20
        oy = 60
        for y, row in enumerate(next_shape):
            for x, cell in enumerate(row):
                if cell:
                    r = pygame.Rect(ox + x * 24, oy + y * 24, 22, 22)
                    pygame.draw.rect(self.screen, self.next_piece.color, r)
                    pygame.draw.rect(self.screen, (0, 0, 0), r, 1)

        # Score info
        y = 180
        for label, value in [("SCORE", self.score), ("HIGH", self.highscore),
                             ("LEVEL", self.level), ("LINES", self.lines_cleared)]:
            self.screen.blit(self.small_font.render(label, True, GRAY), (sidebar_x, y))
            self.screen.blit(self.font.render(str(value), True, WHITE), (sidebar_x, y + 20))
            y += 60

        # Controls hint
        self.screen.blit(self.small_font.render("←→ move  ↑ rot", True, GRAY), (sidebar_x, HEIGHT - 80))
        self.screen.blit(self.small_font.render("↓ soft  SPC hard", True, GRAY), (sidebar_x, HEIGHT - 60))
        self.screen.blit(self.small_font.render("P pause", True, GRAY), (sidebar_x, HEIGHT - 40))

        # Overlays
        if self.paused:
            self._overlay("PAUSED", "Press P to resume")
        elif self.game_over:
            self._overlay("GAME OVER", "Press R to restart")

        pygame.display.flip()

    def _overlay(self, title, subtitle):
        s = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        s.fill((0, 0, 0, 180))
        self.screen.blit(s, (0, 0))
        text = self.big_font.render(title, True, YELLOW)
        sub = self.font.render(subtitle, True, WHITE)
        self.screen.blit(text, text.get_rect(center=(WIDTH // 2, HEIGHT // 2 - 30)))
        self.screen.blit(sub, sub.get_rect(center=(WIDTH // 2, HEIGHT // 2 + 30)))

    def run(self):
        running = True
        while running:
            dt = self.clock.tick(FPS)

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        running = False
                    elif event.key == pygame.K_p and not self.game_over:
                        self.paused = not self.paused
                    elif event.key == pygame.K_r and self.game_over:
                        self.reset()
                    elif not self.game_over and not self.paused and self.clear_anim is None:
                        if event.key == pygame.K_LEFT and self.valid(self.current, dx=-1):
                            self.current.x -= 1
                        elif event.key == pygame.K_RIGHT and self.valid(self.current, dx=1):
                            self.current.x += 1
                        elif event.key == pygame.K_DOWN and self.valid(self.current, dy=1):
                            self.current.y += 1
                            self.score += 1
                        elif event.key == pygame.K_UP:
                            old = [row[:] for row in self.current.shape]
                            self.current.rotate()
                            if not self.valid(self.current):
                                # simple wall-kick try
                                for kick in (-1, 1, -2, 2):
                                    if self.valid(self.current, dx=kick):
                                        self.current.x += kick
                                        break
                                else:
                                    self.current.shape = old
                        elif event.key == pygame.K_SPACE:
                            self.hard_drop()

            self.update(dt)
            self.draw()

        pygame.quit()


if __name__ == "__main__":
    Tetris().run()
