# Modern Tetris

A clean, polished Tetris game written in Python with Pygame.

![Tetris](screenshot.png)  
*(Add your own screenshot after running the game)*

## Features

- Classic Tetris gameplay with all 7 tetrominoes
- Smooth line-clear flash animation
- Ghost piece (preview of where the piece will land)
- Next-piece preview
- Score, Level & Lines counter
- Persistent high score (saved to `highscore.txt`)
- Increasing speed with levels
- Pause support
- Modern dark theme with vibrant colors
- Simple wall-kick on rotation

## Controls

| Key        | Action          |
|------------|-----------------|
| ← →        | Move            |
| ↑          | Rotate          |
| ↓          | Soft drop       |
| Space      | Hard drop       |
| P          | Pause / Resume  |
| R          | Restart (game over) |
| Esc        | Quit            |

## Requirements

- Python 3.8+
- Pygame 2.x

```bash
pip install pygame
```

## Run

```bash
python tetris.py
```

## Project structure

```
tetris/
├── tetris.py        # Main game
├── highscore.txt    # Auto-created high score file
└── README.md
```

## License

MIT – feel free to use, modify and share.
